package com.capg.employee;

import java.util.LinkedList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {
	public static void main(String[] args) {

		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("Employee_Details");
		EntityManager entitymanager = emfactory.createEntityManager();

		// MAX SALARY
		Query query1 = entitymanager.createQuery("Select MAX(e.salary) from Employee e");
		Double result = (Double) query1.getSingleResult();
		System.out.println("Max Employee Salary :" + result);

		
		
		
		// PRINT ALL EMPLOYEE
		Query query = entitymanager.createQuery( "Select e " + "from Employee e " );
	      
	      List<Employee> list=(List<Employee>)query.getResultList( );

	      for( Employee e:list ){
	         System.out.print("Employee ID :" + e.getEid( ));
	         System.out.print("Employee Name :" + e.getEname( ));
	         System.out.println("\t Employee salary :" + e.getSalary( ));
	      }
	      
	      
	      
	       //Between
	      Query query2 = entitymanager.createQuery( "Select e " + "from Employee e " + "where e.salary " + "Between 40000 and 60000" );
	      
	      List<Employee> list2=(List<Employee>)query2.getResultList( );

	      for( Employee e:list2 ){
	         System.out.print("Employee ID :" + e.getEid( ));
	         System.out.print("\tEmployee Name :" + e.getEname( ));
	         System.out.println("\t Employee salary :" + e.getSalary( ));
	      }
	      
	      
	      
	      //salary particular department
	      Query query3 = entitymanager.createQuery( "Select MAX(e.salary) from Employee e group by Department" );
	      List<Employee> list3=(List<Employee>)query3.getResultList( );
	      for( Employee e:list2 ){
	         System.out.print("Employee ID :" + e.getEid( ));
	         System.out.print("\tEmployee Name :" + e.getEname( ));
	         System.out.println("\t Employee salary :" + e.getSalary( ));
	      }


	}
}